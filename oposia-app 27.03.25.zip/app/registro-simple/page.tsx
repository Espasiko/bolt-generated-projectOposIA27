import { RegisterFormSimple } from "@/components/auth/register-form-simple"

export default function RegisterPage() {
  return (
    <div className="container mx-auto py-10">
      <RegisterFormSimple />
    </div>
  )
}

