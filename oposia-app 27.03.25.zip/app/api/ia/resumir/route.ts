import { NextResponse } from "next/server"
import { generateSummaryWithCohere } from "@/lib/ai-service-real"
import { getCurrentUser } from "@/lib/auth-supabase"

export async function POST(request: Request) {
  try {
    // Verificar autenticación
    const userResult = await getCurrentUser()
    if (!userResult) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }

    // Leer el cuerpo de la solicitud
    const body = await request.json()
    const { tema, contenido, longitud } = body

    // Validar parámetros
    if (!tema || !contenido) {
      return NextResponse.json({ error: "Faltan parámetros requeridos" }, { status: 400 })
    }

    // Generar resumen con Cohere
    const response = await generateSummaryWithCohere({
      tema,
      contenido,
      longitud,
    })

    return NextResponse.json({ resumen: response.text })
  } catch (error: any) {
    console.error("Error en API Route /api/ia/resumir:", error)
    return NextResponse.json({ error: error.message || "Error al generar resumen" }, { status: 500 })
  }
}

