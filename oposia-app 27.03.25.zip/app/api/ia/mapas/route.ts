import { NextResponse } from "next/server"
import { generateMindMapWithHF } from "@/lib/ai-service-real"
import { getCurrentUser } from "@/lib/auth-appwrite"
import { createDatabases, COLLECTIONS, createId, getCurrentDate } from "@/lib/appwrite"

export async function POST(request: Request) {
  try {
    // Verificar autenticación
    const userResult = await getCurrentUser()
    if (!userResult) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }

    // Leer el cuerpo de la solicitud
    const body = await request.json()
    const { tema, contenido } = body

    // Validar parámetros
    if (!tema || !contenido) {
      return NextResponse.json({ error: "Faltan parámetros requeridos" }, { status: 400 })
    }

    // Generar mapa mental con Hugging Face
    const response = await generateMindMapWithHF({
      tema,
      contenido,
    })

    // Parsear la respuesta
    let parsedData
    try {
      // Intentar extraer el JSON de la respuesta
      const jsonMatch = response.text.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        parsedData = JSON.parse(jsonMatch[0])
      } else {
        throw new Error("No se pudo extraer JSON de la respuesta")
      }
    } catch (error) {
      console.error("Error al parsear la respuesta:", error)
      return NextResponse.json({ error: "Error al procesar la respuesta de IA" }, { status: 500 })
    }

    const databases = createDatabases()

    // Guardar el mapa mental en la base de datos
    const mapaData = await databases.createDocument(
      process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!,
      COLLECTIONS.MAPAS_MENTALES,
      createId(),
      {
        titulo: tema,
        contenido: parsedData,
        fecha_creacion: getCurrentDate(),
        fecha_actualizacion: getCurrentDate(),
        usuario_id: userResult.user.$id,
      },
    )

    return NextResponse.json(mapaData)
  } catch (error: any) {
    console.error("Error en API Route /api/ia/mapas:", error)
    return NextResponse.json({ error: error.message || "Error al generar mapa mental" }, { status: 500 })
  }
}

