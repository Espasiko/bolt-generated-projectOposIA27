import { NextResponse } from "next/server"
import { generateTestWithCohere } from "@/lib/ai-service-real"
import { getCurrentUser } from "@/lib/auth-appwrite"
import { createDatabases, COLLECTIONS, createId, getCurrentDate } from "@/lib/appwrite"
import { Query } from "appwrite"

export async function POST(request: Request) {
  try {
    // Verificar autenticación
    const userResult = await getCurrentUser()
    if (!userResult) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }

    // Leer el cuerpo de la solicitud
    const body = await request.json()
    const { tema, contenido, numPreguntas, dificultad } = body

    // Validar parámetros
    if (!tema || !contenido || !numPreguntas || !dificultad) {
      return NextResponse.json({ error: "Faltan parámetros requeridos" }, { status: 400 })
    }

    // Generar test con Cohere
    const response = await generateTestWithCohere({
      tema,
      contenido,
      numPreguntas,
      dificultad,
    })

    // Parsear la respuesta
    let parsedData
    try {
      // Intentar extraer el JSON de la respuesta
      const jsonMatch = response.text.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        parsedData = JSON.parse(jsonMatch[0])
      } else {
        throw new Error("No se pudo extraer JSON de la respuesta")
      }
    } catch (error) {
      console.error("Error al parsear la respuesta:", error)
      return NextResponse.json({ error: "Error al procesar la respuesta de IA" }, { status: 500 })
    }

    const databases = createDatabases()
    const testId = createId()

    // Guardar el test en la base de datos
    const testData = await databases.createDocument(
      process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!,
      COLLECTIONS.TESTS,
      testId,
      {
        titulo: `Test sobre ${tema}`,
        descripcion: `Test generado por IA sobre ${tema}. Dificultad: ${dificultad}/5`,
        fecha_creacion: getCurrentDate(),
        dificultad,
        usuario_id: userResult.user.$id,
      },
    )

    // Guardar las preguntas
    const preguntasPromises = parsedData.preguntas.map((pregunta: any) =>
      databases.createDocument(process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!, COLLECTIONS.PREGUNTAS, createId(), {
        test_id: testId,
        pregunta: pregunta.pregunta,
        opciones: pregunta.opciones,
        respuesta_correcta: pregunta.respuesta_correcta,
        explicacion: pregunta.explicacion,
      }),
    )

    await Promise.all(preguntasPromises)

    // Obtener el test completo con sus preguntas
    const preguntas = await databases.listDocuments(
      process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!,
      COLLECTIONS.PREGUNTAS,
      [Query.equal("test_id", testId)],
    )

    const completeTest = {
      ...testData,
      preguntas: preguntas.documents,
    }

    return NextResponse.json(completeTest)
  } catch (error: any) {
    console.error("Error en API Route /api/ia/tests:", error)
    return NextResponse.json({ error: error.message || "Error al generar test" }, { status: 500 })
  }
}

