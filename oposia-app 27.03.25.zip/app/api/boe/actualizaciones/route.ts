import { NextResponse } from "next/server"
import { boeAgentWorkflow } from "@/lib/boe-agent-service"
import { formatearFechaYYYYMMDD } from "@/lib/boe-utils"

/**
 * API Route para obtener actualizaciones del BOE
 * GET /api/boe/actualizaciones?fecha=YYYYMMDD
 */
export async function GET(request: Request) {
  try {
    // Obtener parámetros de la URL
    const { searchParams } = new URL(request.url)
    const fecha = searchParams.get("fecha")

    // Si no se proporciona fecha, usar la fecha actual
    const fechaConsulta = fecha || formatearFechaYYYYMMDD(new Date())

    // Validar formato de fecha (YYYYMMDD)
    if (!/^\d{8}$/.test(fechaConsulta)) {
      return NextResponse.json({ error: "Formato de fecha inválido. Debe ser YYYYMMDD" }, { status: 400 })
    }

    // Ejecutar flujo de trabajo de agentes
    const actualizacion = await boeAgentWorkflow.run(fechaConsulta)

    return NextResponse.json({ actualizacion })
  } catch (error) {
    console.error("Error en API Route /api/boe/actualizaciones:", error)
    return NextResponse.json({ error: "Error al procesar la solicitud" }, { status: 500 })
  }
}

