import { NextResponse } from "next/server"
import { account } from "@/lib/appwrite"

export async function GET() {
  try {
    console.log("Verificando autenticación...")

    // Verificar si hay una sesión activa
    const user = await account.get()

    console.log("Usuario autenticado:", user.$id)

    return NextResponse.json({
      success: true,
      user: {
        id: user.$id,
        email: user.email,
        name: user.name,
      },
    })
  } catch (error: any) {
    console.error("Error al verificar autenticación:", error)

    // Si el error es que no hay sesión, devolver un 401
    if (error.code === 401) {
      return NextResponse.json(
        {
          success: false,
          message: "No autenticado",
        },
        { status: 401 },
      )
    }

    // Para otros errores, devolver un 500
    return NextResponse.json(
      {
        success: false,
        message: error.message || "Error al verificar autenticación",
      },
      { status: 500 },
    )
  }
}

