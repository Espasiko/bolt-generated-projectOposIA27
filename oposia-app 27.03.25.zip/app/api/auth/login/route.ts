import { NextResponse } from "next/server"
import { AppwriteApi } from "@/lib/appwrite-api"

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ message: "Email y contraseña son requeridos" }, { status: 400 })
    }

    // Crear sesión usando la API REST directamente
    const session = await AppwriteApi.createSession(email, password)

    // Obtener datos del usuario
    const user = await AppwriteApi.getAccount()

    if (!user) {
      return NextResponse.json({ message: "Error al obtener datos del usuario" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.$id,
        email: user.email,
        name: user.name,
      },
      session: {
        id: session.$id,
      },
    })
  } catch (error: any) {
    console.error("Error en la API de login:", error)

    // Manejar errores específicos
    if (error.message.includes("Invalid credentials")) {
      return NextResponse.json({ message: "Credenciales incorrectas" }, { status: 401 })
    }

    return NextResponse.json({ message: error.message || "Error al iniciar sesión" }, { status: 500 })
  }
}

