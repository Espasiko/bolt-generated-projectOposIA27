import { NextResponse } from "next/server"
import { AppwriteApi } from "@/lib/appwrite-api"

export async function GET() {
  try {
    // Obtener usuario actual usando la API REST directamente
    const user = await AppwriteApi.getAccount()

    if (!user) {
      return NextResponse.json({ message: "No autenticado" }, { status: 401 })
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.$id,
        email: user.email,
        name: user.name,
      },
    })
  } catch (error: any) {
    console.error("Error en la API de usuario:", error)

    return NextResponse.json({ message: error.message || "Error al obtener usuario" }, { status: 500 })
  }
}

