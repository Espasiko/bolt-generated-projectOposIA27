import { AppwriteConfigInfo } from "@/components/debug/appwrite-config-info"

export default function DiagnosticoPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Diagnóstico de Appwrite</h1>

      <div className="space-y-8">
        <section>
          <h2 className="text-xl font-semibold mb-4">Configuración de Appwrite</h2>
          <AppwriteConfigInfo />
        </section>

        <section className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Solución de problemas comunes</h2>

          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">
                Error: Appwrite: El método createEmailSession no está disponible en el objeto account
              </h3>
              <p className="text-gray-700">
                Este error indica un problema con la versión del SDK de Appwrite. Solución implementada:
              </p>
              <ul className="list-disc pl-5 mt-2">
                <li>Se ha creado un servicio de autenticación que no depende de la versión del SDK</li>
                <li>Este servicio utiliza el SDK si los métodos están disponibles, o la API REST si no lo están</li>
                <li>Se han implementado rutas de API para todas las operaciones de autenticación</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold">Error: Failed to fetch</h3>
              <p className="text-gray-700">
                Este error indica problemas de conectividad con la API de Appwrite. Posibles soluciones:
              </p>
              <ul className="list-disc pl-5 mt-2">
                <li>Verifica que la URL del endpoint de Appwrite es correcta</li>
                <li>Asegúrate de que el servidor de Appwrite está en funcionamiento</li>
                <li>Verifica la configuración de CORS en Appwrite</li>
                <li>Comprueba si hay problemas de red o firewall</li>
              </ul>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

