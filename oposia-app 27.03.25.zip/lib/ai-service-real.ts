import { CohereClient } from "cohere-ai"
import { HfInference } from "@huggingface/inference"
import type { TestGenerationParams, MapaGenerationParams, ResumenGenerationParams } from "./ai-service"

// Inicializar clientes
const cohere = new CohereClient({
  token: process.env.COHERE_API_KEY || "",
})

const hf = new HfInference(process.env.HF_API_KEY)

// Función para generar un test con Cohere
export async function generateTestWithCohere(params: TestGenerationParams) {
  try {
    const prompt = `
      Genera un test de opción múltiple sobre el tema "${params.tema}" con ${params.numPreguntas} preguntas.
      Nivel de dificultad: ${params.dificultad}/5.
      
      Basado en el siguiente contenido:
      ${params.contenido}
      
      Formato de salida:
      {
        "preguntas": [
          {
            "pregunta": "Texto de la pregunta",
            "opciones": ["Opción A", "Opción B", "Opción C", "Opción D"],
            "respuesta_correcta": 0, // Índice de la opción correcta (0-3)
            "explicacion": "Explicación de por qué esta es la respuesta correcta"
          },
          // Más preguntas...
        ]
      }
    `

    const response = await cohere.generate({
      prompt,
      model: "command-xl",
      maxTokens: 2000,
      temperature: 0.7,
      returnLikelihoods: "NONE",
    })

    return {
      text: response.generations[0].text,
      model: "cohere-command-xl",
      tokensUsed: response.meta?.billed_units?.input_tokens || 0 + response.meta?.billed_units?.output_tokens || 0,
    }
  } catch (error) {
    console.error("Error generando test con Cohere:", error)
    throw new Error("No se pudo generar el test")
  }
}

// Función para generar un mapa mental con Hugging Face
export async function generateMindMapWithHF(params: MapaGenerationParams) {
  try {
    const prompt = `
      Genera un mapa mental sobre el tema "${params.tema}".
      
      Basado en el siguiente contenido:
      ${params.contenido}
      
      Formato de salida:
      {
        "nodo_central": {
          "texto": "Concepto principal",
          "hijos": [
            {
              "texto": "Concepto secundario 1",
              "hijos": [
                {"texto": "Detalle 1"},
                {"texto": "Detalle 2"}
              ]
            },
            {
              "texto": "Concepto secundario 2",
              "hijos": []
            }
          ]
        }
      }
    `

    const response = await hf.textGeneration({
      model: "mistralai/Mistral-7B-Instruct-v0.2",
      inputs: prompt,
      parameters: {
        max_new_tokens: 1000,
        temperature: 0.7,
      },
    })

    return {
      text: response.generated_text,
      model: "huggingface-mistral-7b",
      tokensUsed: prompt.length / 4, // Estimación simple
    }
  } catch (error) {
    console.error("Error generando mapa mental con Hugging Face:", error)
    throw new Error("No se pudo generar el mapa mental")
  }
}

// Función para generar un resumen con Cohere
export async function generateSummaryWithCohere(params: ResumenGenerationParams) {
  try {
    const longitud = params.longitud || "medio"
    const longitudMap = {
      corto: 150,
      medio: 300,
      largo: 600,
    }

    const response = await cohere.summarize({
      text: params.contenido,
      length: longitud as "short" | "medium" | "long",
      format: "paragraph",
      extractiveness: "medium",
      temperature: 0.7,
    })

    return {
      text: response.summary,
      model: "cohere-summarize-medium",
      tokensUsed: params.contenido.length / 4, // Estimación simple
    }
  } catch (error) {
    console.error("Error generando resumen con Cohere:", error)
    throw new Error("No se pudo generar el resumen")
  }
}

// Función para analizar documentos del BOE con Cohere
export async function analyzeBOEDocumentWithCohere(url: string, content: string) {
  try {
    const prompt = `
      Analiza el siguiente documento del BOE y extrae los cambios más relevantes en materia de Seguridad Social:
      
      URL: ${url}
      
      Contenido:
      ${content.substring(0, 5000)}...
      
      Proporciona un análisis detallado que incluya:
      1. Relevancia para las oposiciones de Seguridad Social (puntuación de 0 a 100)
      2. Principales cambios o novedades introducidas
      3. Temas del temario que podrían verse afectados
      4. Recomendaciones para los opositores
    `

    const response = await cohere.generate({
      prompt,
      model: "command-xl",
      maxTokens: 1000,
      temperature: 0.7,
      returnLikelihoods: "NONE",
    })

    return {
      text: response.generations[0].text,
      model: "cohere-command-xl",
      tokensUsed: prompt.length / 4, // Estimación simple
    }
  } catch (error) {
    console.error("Error analizando documento del BOE:", error)
    throw new Error("No se pudo analizar el documento")
  }
}

