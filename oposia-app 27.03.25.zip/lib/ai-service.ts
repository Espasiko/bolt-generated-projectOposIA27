export interface TestGenerationParams {
  tema: string
  contenido: string
  numPreguntas: number
  dificultad: 1 | 2 | 3 | 4 | 5
}

export interface MapaGenerationParams {
  tema: string
  contenido: string
}

export interface ResumenGenerationParams {
  tema: string
  contenido: string
  longitud: "corto" | "medio" | "largo"
}

/**
 * Servicio simulado para la generación de contenido con IA.
 * En un entorno real, estas funciones harían llamadas a APIs de IA como Cohere, OpenAI, etc.
 */

export async function generateTest(params: TestGenerationParams): Promise<{ text: string }> {
  // Simulación de la respuesta de la API de IA para generar un test
  console.log("Generando test simulado con los parámetros:", params)
  const mockQuestions = [
    {
      pregunta: "¿Cuál es el campo de aplicación del Régimen General de la Seguridad Social?",
      opciones: [
        "Trabajadores por cuenta ajena",
        "Funcionarios públicos",
        "Trabajadores autónomos",
        "Todos los ciudadanos",
      ],
      respuesta_correcta: 0,
      explicacion: "El Régimen General se aplica principalmente a trabajadores por cuenta ajena.",
    },
    {
      pregunta: "¿Qué es la base de cotización?",
      opciones: [
        "La remuneración total del trabajador",
        "La parte de la remuneración sujeta a cotización",
        "El importe de la prestación por desempleo",
        "El salario mínimo interprofesional",
      ],
      respuesta_correcta: 1,
      explicacion:
        "La base de cotización es la parte de la remuneración del trabajador que se utiliza para calcular las cotizaciones a la Seguridad Social.",
    },
  ]

  const mockResponse = {
    preguntas: mockQuestions,
  }

  return {
    text: JSON.stringify(mockResponse),
  }
}

export async function generateMindMap(params: MapaGenerationParams): Promise<{ text: string }> {
  // Simulación de la respuesta de la API de IA para generar un mapa mental
  console.log("Generando mapa mental simulado con los parámetros:", params)

  const mockMindMap = {
    nodo_central: {
      texto: params.tema,
      hijos: [
        { texto: "Concepto 1", hijos: [{ texto: "Subconcepto 1.1" }, { texto: "Subconcepto 1.2" }] },
        { texto: "Concepto 2", hijos: [] },
      ],
    },
  }

  return {
    text: JSON.stringify(mockMindMap),
  }
}

export async function generateSummary(text: string, length: "short" | "medium" | "long" = "medium"): Promise<string> {
  // Simulación de la respuesta de la API de IA para generar un resumen
  console.log("Generando resumen simulado para el texto:", text, "Longitud:", length)
  return `Este es un resumen simulado de longitud ${length} para el texto proporcionado.  Este servicio aún no está implementado.`
}

export async function classifyText(text: string): Promise<string> {
  // Simulación de la respuesta de la API de IA para clasificar texto
  console.log("Clasificando texto simulado:", text)
  return "Seguridad Social - Régimen General"
}

export async function generateQuestions(text: string, numQuestions = 5): Promise<string[]> {
  // Simulación de la respuesta de la API de IA para generar preguntas
  console.log("Generando preguntas simuladas para el texto:", text, "Número de preguntas:", numQuestions)
  const mockQuestions = [
    "¿Cuál es el concepto principal?",
    "¿Cuáles son los elementos clave?",
    "¿Cómo se relaciona con otros temas?",
  ]
  return mockQuestions.slice(0, numQuestions)
}

