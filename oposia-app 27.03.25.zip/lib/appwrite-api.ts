// Utilidades para interactuar directamente con la API REST de Appwrite
// sin depender del SDK

// Configuración de Appwrite
const APPWRITE_ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://cloud.appwrite.io/v1"
const APPWRITE_PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || ""

// Función para obtener los headers básicos
const getHeaders = (session?: string) => {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "X-Appwrite-Project": APPWRITE_PROJECT_ID,
  }

  if (session) {
    headers["X-Appwrite-Session"] = session
  }

  return headers
}

// API de Appwrite
export const AppwriteApi = {
  // Crear una sesión (login)
  async createSession(email: string, password: string) {
    try {
      console.log("AppwriteApi: Creando sesión para", email)

      const response = await fetch(`${APPWRITE_ENDPOINT}/account/sessions/email`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({ email, password }),
        credentials: "include",
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Error al iniciar sesión")
      }

      return await response.json()
    } catch (error: any) {
      console.error("AppwriteApi: Error al crear sesión", error)
      throw error
    }
  },

  // Obtener la sesión actual
  async getSession() {
    try {
      console.log("AppwriteApi: Obteniendo sesión actual")

      const response = await fetch(`${APPWRITE_ENDPOINT}/account/sessions/current`, {
        method: "GET",
        headers: getHeaders(),
        credentials: "include",
      })

      if (!response.ok) {
        return null
      }

      return await response.json()
    } catch (error) {
      console.error("AppwriteApi: Error al obtener sesión", error)
      return null
    }
  },

  // Eliminar la sesión actual (logout)
  async deleteSession() {
    try {
      console.log("AppwriteApi: Eliminando sesión actual")

      const response = await fetch(`${APPWRITE_ENDPOINT}/account/sessions/current`, {
        method: "DELETE",
        headers: getHeaders(),
        credentials: "include",
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Error al cerrar sesión")
      }

      return true
    } catch (error) {
      console.error("AppwriteApi: Error al eliminar sesión", error)
      throw error
    }
  },

  // Crear un usuario (registro)
  async createUser(email: string, password: string, name: string) {
    try {
      console.log("AppwriteApi: Creando usuario", email)

      const userId = "unique()" // Appwrite generará un ID único

      const response = await fetch(`${APPWRITE_ENDPOINT}/account`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({ userId, email, password, name }),
        credentials: "include",
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Error al registrar usuario")
      }

      return await response.json()
    } catch (error) {
      console.error("AppwriteApi: Error al crear usuario", error)
      throw error
    }
  },

  // Obtener el usuario actual
  async getAccount() {
    try {
      console.log("AppwriteApi: Obteniendo cuenta actual")

      const response = await fetch(`${APPWRITE_ENDPOINT}/account`, {
        method: "GET",
        headers: getHeaders(),
        credentials: "include",
      })

      if (!response.ok) {
        return null
      }

      return await response.json()
    } catch (error) {
      console.error("AppwriteApi: Error al obtener cuenta", error)
      return null
    }
  },
}

