"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { AuthService } from "@/lib/auth-service"

interface User {
  id: string
  email: string
  name: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, name: string, location?: string) => Promise<void>
  logout: () => Promise<void>
  checkAuth: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  // Función para verificar autenticación
  const checkAuth = async () => {
    try {
      setLoading(true)
      setError(null)

      const currentUser = await AuthService.getCurrentUser()
      setUser(currentUser)
    } catch (err: any) {
      console.error("Error al verificar autenticación:", err)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  // Verificar autenticación al cargar
  useEffect(() => {
    checkAuth()
  }, [])

  // Función para iniciar sesión
  const login = async (email: string, password: string) => {
    try {
      setLoading(true)
      setError(null)

      const user = await AuthService.login(email, password)
      setUser(user)
      router.push("/")
    } catch (err: any) {
      console.error("Error al iniciar sesión:", err)
      setError(err.message || "Error al iniciar sesión")
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Función para registrarse
  const register = async (email: string, password: string, name: string, location?: string) => {
    try {
      setLoading(true)
      setError(null)

      const user = await AuthService.register(email, password, name)
      setUser(user)

      // Crear perfil de usuario en la base de datos (opcional)
      try {
        await fetch("/api/auth/create-profile", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId: user.id,
            email,
            name,
            location: location || "",
          }),
        })
      } catch (profileError) {
        console.error("Error al crear perfil de usuario:", profileError)
        // No interrumpimos el flujo si falla la creación del perfil
      }

      router.push("/")
    } catch (err: any) {
      console.error("Error al registrarse:", err)
      setError(err.message || "Error al registrarse")
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Función para cerrar sesión
  const logout = async () => {
    try {
      setLoading(true)
      setError(null)

      await AuthService.logout()
      setUser(null)
      router.push("/login")
    } catch (err: any) {
      console.error("Error al cerrar sesión:", err)
      setError(err.message || "Error al cerrar sesión")
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, error, login, register, logout, checkAuth }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth debe ser usado dentro de un AuthProvider")
  }
  return context
}

