"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, FileText, AlertTriangle, Loader2 } from "lucide-react"
import type { BOEActualizacion, BOEDocumento } from "@/lib/boe-types"
import Link from "next/link"

export function BOEActualizaciones() {
  const [actualizacion, setActualizacion] = useState<BOEActualizacion | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchActualizaciones = async () => {
      try {
        setLoading(true)
        setError(null)

        // Obtener fecha actual en formato YYYYMMDD
        const today = new Date()
        const fechaStr =
          today.getFullYear().toString() +
          (today.getMonth() + 1).toString().padStart(2, "0") +
          today.getDate().toString().padStart(2, "0")

        const response = await fetch(`/api/boe/actualizaciones?fecha=${fechaStr}`)

        if (!response.ok) {
          throw new Error(`Error al obtener actualizaciones: ${response.status}`)
        }

        const data = await response.json()
        setActualizacion(data.actualizacion)
      } catch (err) {
        console.error("Error al obtener actualizaciones del BOE:", err)
        setError("No se pudieron cargar las actualizaciones del BOE")
      } finally {
        setLoading(false)
      }
    }

    fetchActualizaciones()
  }, [])

  // Renderizar estado de carga
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">BOE actualizado</CardTitle>
          <CardDescription>Cargando actualizaciones recientes...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    )
  }

  // Renderizar estado de error
  if (error || !actualizacion) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">BOE actualizado</CardTitle>
          <CardDescription>Cambios recientes en la normativa de Seguridad Social</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <AlertTriangle className="h-10 w-10 text-muted-foreground mb-4" />
            <h3 className="text-base font-medium">No se pudieron cargar las actualizaciones</h3>
            <p className="text-sm text-muted-foreground mt-2 mb-4">
              {error || "Hubo un problema al obtener las actualizaciones del BOE"}
            </p>
            <Button onClick={() => window.location.reload()}>Reintentar</Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Renderizar actualizaciones
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl">BOE actualizado</CardTitle>
        <CardDescription>Cambios recientes en la normativa de Seguridad Social</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 sm:space-y-4">
          {actualizacion.documentos.length > 0 ? (
            <>
              {actualizacion.documentos.slice(0, 3).map((documento: BOEDocumento, index: number) => (
                <div key={documento.id} className="flex items-start gap-3 sm:gap-4 rounded-lg border p-2 sm:p-3">
                  <div className="space-y-1">
                    <p className="text-xs sm:text-sm font-medium leading-none">{documento.titulo}</p>
                    <p className="text-xs text-muted-foreground">
                      {documento.resumen ? documento.resumen.split("\n")[0] : "Sin resumen disponible"}
                    </p>
                    {documento.relevancia_ss >= 70 && (
                      <div className="mt-1 inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300">
                        Alta relevancia
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <Button variant="outline" className="w-full" asChild>
                <Link href="/boe">
                  Ver más actualizaciones
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <FileText className="h-10 w-10 text-muted-foreground mb-4" />
              <h3 className="text-base font-medium">No hay actualizaciones recientes</h3>
              <p className="text-sm text-muted-foreground mt-2">
                No se encontraron actualizaciones relevantes en el BOE para la fecha actual
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

