// The rest of the code would go here, assuming it's correct as stated in the prompt.
// Since the existing code is not provided, I cannot add any more details.

