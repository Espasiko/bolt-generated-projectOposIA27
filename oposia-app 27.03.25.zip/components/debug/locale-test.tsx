// The rest of the code from the original file would go here.
// Since the original file is not provided, I cannot add any specific test cases.
// However, the import statement above should resolve the errors mentioned in the updates.

