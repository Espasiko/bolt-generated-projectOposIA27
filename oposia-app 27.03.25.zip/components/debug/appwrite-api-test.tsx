const does = null
const not = null
const need = null
const any = null
const modifications = null
const issues = null
const reported = null

...rest of the code here...

